using System;

class Program
{
    static void SortArray(ref int[] arr)
    {
        Array.Sort(arr);
    }
}