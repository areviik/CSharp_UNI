using System;

class Program
{
    static void GetLength(in string word, out int length)
    {
        length = word.Length;
    }
}